import React, { useEffect } from "react";
import './Reversemove.css';

function Reversemove() {
  useEffect(() => {
    const scrollers = document.querySelectorAll(".scroller");

    // If a user hasn't opted in for reduced motion, then we add the animation
    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      addAnimation();
    }

    function addAnimation() {
      scrollers.forEach((scroller) => {
        // add data-animated="true" to every `.scroller` on the page
        scroller.setAttribute("data-animated", true);

        // Make an array from the elements within `.scroller-inner`
        const scrollerInner = scroller.querySelector(".scroller__inner");
        const scrollerContent = Array.from(scrollerInner.children);

        // For each item in the array, clone it
        // add aria-hidden to it
        // add it into the `.scroller-inner`
        scrollerContent.forEach((item) => {
          const duplicatedItem = item.cloneNode(true);
          duplicatedItem.setAttribute("aria-hidden", true);
          scrollerInner.appendChild(duplicatedItem);
        });
      });
    }
  }, []); // Empty dependency array ensures that useEffect runs only once after the initial render

  return (
    <>

      <div className="scroller" data-speed="slow">
        <div className="tag-list scroller__inner">
          <li>
             <img src="https://i.pravatar.cc/150?img=1" alt="" className="feed_back_image"/>
             <div>
                <p>well traning & <br/>placement</p>
             </div>
          </li>
          <li>
             <img src="https://i.pravatar.cc/150?img=2" alt="" className="feed_back_image"/>
             <div>
                <p>well traning & <br/>placement</p>
             </div>
          </li>
          <li>
             <img src="https://i.pravatar.cc/150?img=3" alt="" className="feed_back_image"/>
             <div>
                <p>well traning & <br/>placement</p>
             </div>
          </li>
          <li>
             <img src="https://i.pravatar.cc/150?img=4" alt="" className="feed_back_image"/>
             <div>
                <p>well traning & <br/>placement</p>
             </div>
          </li>
          <li>
             <img src="https://i.pravatar.cc/150?img=5" alt="" className="feed_back_image"/>
             <div>
                <p>well traning & <br/>placement</p>
             </div>
          </li>
          <li>
             <img src="https://i.pravatar.cc/150?img=6" alt="" className="feed_back_image"/>
             <div>
                <p>well traning & <br/>placement</p>
             </div>
          </li>
         
        </div>
      </div>
      
      <div className="scroller" data-direction="right" data-speed="slow">
        <div className="scroller__inner">
            <div className="feed_back_item">
                <img src="https://i.pravatar.cc/150?img=1" alt="" className="feed_back_image"/>
                   <div>
                        <p>well traning & <br/>placement</p>
                    </div>
            </div>

            <div className="feed_back_item">
                <img src="https://i.pravatar.cc/150?img=2" alt="" className="feed_back_image"/>
                <div>
                        <p>well traning & <br/>placement</p>
                    </div>
            </div>

            <div className="feed_back_item">
                <img src="https://i.pravatar.cc/150?img=3" alt="" className="feed_back_image"/>
                <div>
                        <p>well traning & <br/>placement</p>
                    </div>
            </div>

            <div className="feed_back_item">
                <img src="https://i.pravatar.cc/150?img=4" alt="" className="feed_back_image"/>
                <div>
                        <p>well traning & <br/>placement</p>
                    </div>
            </div>

            <div className="feed_back_item">
                <img src="https://i.pravatar.cc/150?img=5" alt="" className="feed_back_image"/>
                <div>
                        <p>well traning & <br/>placement</p>
                    </div>
            </div>

            <div className="feed_back_item">
                <img src="https://i.pravatar.cc/150?img=6" alt="" className="feed_back_image"/>
                <div>
                        <p>well traning & <br/>placement</p>
                    </div>
            </div>
          
        </div>
      </div>
    
    </>
  );
}

export default Reversemove;
